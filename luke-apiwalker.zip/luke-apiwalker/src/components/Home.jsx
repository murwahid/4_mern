import React from 'react'

function Home(props) {
  return (
    <div>Home
        <h1>Home Component</h1>
    </div>
  )
}

export default Home; 