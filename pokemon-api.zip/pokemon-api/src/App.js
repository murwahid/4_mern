import logo from './logo.svg';
import './App.css';
import Example from './components/Example';

function App() {
  return (
    <div className="App">
      <Example/>
    </div>
  );
}

export default App;
