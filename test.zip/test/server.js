//IMPORTS
const express = require('express');
const app = express();
const port = 8000;
const cors = require('cors');

//IMPORT.CORS
app.use(cors());

//EXPRESS
app.use(express.json()); // This is new
app.use(express.urlencoded({ extended: true }));

//FILE: ROUTES
require('./server/routes/pet.routes')(app);

//FILE:SERVER
require('./server/config/mongoose.config');

app.listen(port,()=>console.log(`Listening on port: ${port}`))
